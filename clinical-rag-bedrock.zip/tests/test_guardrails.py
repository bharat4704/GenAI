from src.guardrails import (
    CLINICAL_DISCLAIMER,
    has_sufficient_grounding,
    redact_phi,
    with_disclaimer,
)


def test_redact_ssn():
    text = "Patient SSN: 123-45-6789 presented with chest pain."
    redacted = redact_phi(text)
    assert "123-45-6789" not in redacted
    assert "[REDACTED-SSN]" in redacted


def test_redact_mrn():
    text = "MRN: 0012345 - follow up in 2 weeks."
    redacted = redact_phi(text)
    assert "0012345" not in redacted
    assert "[REDACTED-MRN]" in redacted


def test_redact_dob():
    text = "DOB 04/12/1985, admitted for elective surgery."
    redacted = redact_phi(text)
    assert "04/12/1985" not in redacted
    assert "[REDACTED-DOB]" in redacted


def test_no_false_positive_on_dosage():
    # Numeric dosage strings shouldn't accidentally match PHI patterns.
    text = "Metformin 500 mg twice daily with meals."
    redacted = redact_phi(text)
    assert redacted == text


def test_with_disclaimer_appends_text():
    answer = "Metformin is first-line therapy."
    result = with_disclaimer(answer)
    assert result.startswith(answer)
    assert CLINICAL_DISCLAIMER.strip() in result


def test_has_sufficient_grounding():
    assert has_sufficient_grounding([]) is False
    assert has_sufficient_grounding([object()]) is True
