"""
Interactive CLI: python -m src.app

Loads the FAISS index + Bedrock chain once, then loops on user questions.
"""
from src.rag_chain import ClinicalRAGChain


def main():
    print("Loading Clinical Doc Q&A (Bedrock + LangChain) ...")
    try:
        rag = ClinicalRAGChain()
    except FileNotFoundError as e:
        print(f"\nError: {e}")
        return

    print("\nClinical Doc Q&A — type 'exit' to quit\n")
    while True:
        question = input("> ").strip()
        if not question:
            continue
        if question.lower() in {"exit", "quit"}:
            break

        try:
            result = rag.ask(question)
        except Exception as e:  # noqa: BLE001 - surface any Bedrock/auth error to the user
            print(f"\n[Error] {e}\n")
            continue

        print(f"\n{result['answer']}\n")
        if result["sources"]:
            print(f"Sources: {', '.join(result['sources'])}\n")


if __name__ == "__main__":
    main()
