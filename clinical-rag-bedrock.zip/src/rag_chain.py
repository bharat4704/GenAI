"""
Retrieval-augmented generation chain: FAISS retriever -> prompt -> Claude on
Bedrock, using LangChain Expression Language (LCEL) so it's easy to extend
(add memory, swap retriever, add re-ranking, etc.).
"""
from pathlib import Path

from langchain_aws import BedrockEmbeddings, ChatBedrock
from langchain_community.vectorstores import FAISS
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableParallel, RunnablePassthrough

from src.config import settings
from src.guardrails import (
    NO_GROUNDING_RESPONSE,
    has_sufficient_grounding,
    with_disclaimer,
)

SYSTEM_PROMPT = """You are a clinical reference assistant used by care teams to
look up information from a fixed set of internal clinical guidelines.

Rules you must follow strictly:
- Answer ONLY using the information in the provided context. Do not use
  outside knowledge, even if you believe you know the answer.
- If the context does not contain enough information to answer confidently,
  say so explicitly instead of guessing.
- Always cite which source document(s) your answer is drawn from.
- Be precise about dosing, thresholds, and numeric values — do not round or
  approximate figures that appear in the context.
- Keep the tone clinical and concise. This is a reference tool for
  professionals, not patient-facing advice.

Context:
{context}
"""

USER_PROMPT = "{question}"


def _format_docs(docs) -> str:
    formatted = []
    for i, doc in enumerate(docs, start=1):
        source = doc.metadata.get("source", "unknown")
        formatted.append(f"[Source {i}: {source}]\n{doc.page_content}")
    return "\n\n".join(formatted)


def load_vectorstore() -> FAISS:
    index_path = Path(settings.vector_store_path)
    if not index_path.exists():
        raise FileNotFoundError(
            f"No index found at {index_path.resolve()}. Run `python -m src.build_index` first."
        )
    embeddings = BedrockEmbeddings(
        model_id=settings.bedrock_embedding_model_id,
        region_name=settings.aws_region,
    )
    return FAISS.load_local(
        str(index_path), embeddings, allow_dangerous_deserialization=True
    )


def build_llm() -> ChatBedrock:
    model_kwargs = {"temperature": 0.0, "max_tokens": 1024}
    kwargs = {
        "model_id": settings.bedrock_llm_model_id,
        "region_name": settings.aws_region,
        "model_kwargs": model_kwargs,
    }
    if settings.guardrail_id:
        kwargs["guardrails"] = {
            "guardrailIdentifier": settings.guardrail_id,
            "guardrailVersion": settings.guardrail_version,
            "trace": "enabled",
        }
    return ChatBedrock(**kwargs)


class ClinicalRAGChain:
    """Thin wrapper exposing a simple .ask(question) -> dict interface."""

    def __init__(self):
        self.vectorstore = load_vectorstore()
        self.retriever = self.vectorstore.as_retriever(
            search_type="similarity_score_threshold",
            search_kwargs={
                "k": settings.top_k,
                "score_threshold": settings.score_threshold,
            },
        )
        self.llm = build_llm()

        prompt = ChatPromptTemplate.from_messages(
            [("system", SYSTEM_PROMPT), ("human", USER_PROMPT)]
        )

        self.chain = (
            RunnableParallel(
                {"docs": self.retriever, "question": RunnablePassthrough()}
            )
            | RunnableParallel(
                {
                    "answer": (
                        {
                            "context": lambda x: _format_docs(x["docs"]),
                            "question": lambda x: x["question"],
                        }
                        | prompt
                        | self.llm
                        | StrOutputParser()
                    ),
                    "docs": lambda x: x["docs"],
                }
            )
        )

    def ask(self, question: str) -> dict:
        docs = self.retriever.invoke(question)
        if not has_sufficient_grounding(docs):
            return {"answer": NO_GROUNDING_RESPONSE, "sources": []}

        result = self.chain.invoke(question)
        sources = sorted({d.metadata.get("source", "unknown") for d in result["docs"]})
        return {
            "answer": with_disclaimer(result["answer"]),
            "sources": sources,
        }
