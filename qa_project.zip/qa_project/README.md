# End-to-End QA with LangChain + AWS Bedrock

A Retrieval-Augmented Generation (RAG) question-answering system built with LangChain
and AWS Bedrock, in a single runnable Jupyter notebook.

## Contents

```
qa_project/
├── End_to_End_QA_LangChain_Bedrock.ipynb   # the main notebook — start here
├── requirements.txt
├── sample_docs/                            # tiny sample knowledge base
│   ├── company_handbook.txt
│   ├── product_faq.txt
│   └── support_policy.txt
└── README.md
```

## What it does

1. Loads documents from `sample_docs/`
2. Splits them into overlapping chunks
3. Embeds the chunks with Amazon Titan Text Embeddings (via Bedrock)
4. Stores the embeddings in a local FAISS vector index
5. Retrieves relevant chunks for a question
6. Answers the question with Claude on Bedrock, grounded in the retrieved context
7. Bonus: a conversational, tool-calling agent (via `langchain.agents.create_agent`)
   that remembers earlier turns in a conversation

## Setup

1. **AWS account & Bedrock access**: In the AWS Console, go to **Bedrock → Model access**
   and request access to:
   - `amazon.titan-embed-text-v2:0`
   - `anthropic.claude-3-5-sonnet-20240620-v1:0` (or another Claude model you prefer)

2. **AWS credentials**: set these in your shell before launching Jupyter (don't hardcode them
   in the notebook):
   ```bash
   export AWS_ACCESS_KEY_ID=your_key_id
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   ```
   Your IAM user/role needs `bedrock:InvokeModel` permission (and `bedrock:ListFoundationModels`
   if you want to run the optional model-listing sanity check).

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the notebook**:
   ```bash
   jupyter notebook End_to_End_QA_LangChain_Bedrock.ipynb
   ```
   Run the cells top to bottom.

## Using your own data

Replace the files in `sample_docs/` with your own `.txt` files, or swap the loader in the
notebook (`DirectoryLoader` + `TextLoader`) for one of LangChain's other document loaders
(`PyPDFLoader`, `UnstructuredWordDocumentLoader`, `WebBaseLoader`, `S3DirectoryLoader`, etc.)
to ingest PDFs, Word docs, web pages, or S3 buckets. Everything downstream (splitting,
embedding, retrieval, answering) stays the same.

## Notes on versions

This notebook targets **LangChain v1.x**, which replaced the old `RetrievalQA` and
`ConversationalRetrievalChain` classes with LCEL pipelines and the LangGraph-based
`create_agent` API. If you're pinned to an older LangChain 0.x release, the legacy chain
classes still exist there but are deprecated upstream.
