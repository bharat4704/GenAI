"""
CLI entrypoint: python -m src.build_index

Runs the full ingestion pipeline and prints a short summary. Re-run this any
time documents in data/sample_docs/ change.
"""
from src.ingest import run_ingestion


def main():
    print("Building vector index from data/sample_docs ...")
    run_ingestion()
    print("Done. Run `python -m src.app` to start asking questions.")


if __name__ == "__main__":
    main()
