"""
Lightweight, local guardrails for the Clinical Doc Q&A project.

This module is a *stand-in* for a real guardrail service. In production, pair
it with Amazon Bedrock Guardrails (content filters, denied topics, PII
masking) attached directly to the model invocation — see README.md section 6.

What this module actually does:
1. Redacts common PHI-shaped patterns (SSNs, MRNs, DOB-like strings) from any
   text before it is logged or persisted, so accidental PHI in an uploaded
   document doesn't leak into logs.
2. Appends a standing clinical-use disclaimer to every model answer.
3. Provides a simple relevance check so the app doesn't fabricate an answer
   when nothing relevant was retrieved.
"""
import re

CLINICAL_DISCLAIMER = (
    "\n\n---\n"
    "This response is generated from retrieved reference material for "
    "informational support only. It is not a substitute for clinical "
    "judgment, and it does not constitute medical advice for any specific "
    "patient. Verify against current primary sources and institutional "
    "policy before acting."
)

# Patterns are intentionally conservative (favor false positives over misses).
_PHI_PATTERNS = [
    (re.compile(r"\b\d{3}-\d{2}-\d{4}\b"), "[REDACTED-SSN]"),                    # SSN
    (re.compile(r"\bMRN[\s:#-]*\d{5,10}\b", re.IGNORECASE), "[REDACTED-MRN]"),   # MRN
    (re.compile(r"\b(?:0[1-9]|1[0-2])[/-](?:0[1-9]|[12]\d|3[01])[/-](?:19|20)\d{2}\b"), "[REDACTED-DOB]"),  # MM/DD/YYYY
    (re.compile(r"\b\d{3}[.\s-]?\d{3}[.\s-]?\d{4}\b"), "[REDACTED-PHONE]"),      # phone-like
]


def redact_phi(text: str) -> str:
    """Redact common PHI-shaped substrings from text before logging/indexing."""
    redacted = text
    for pattern, placeholder in _PHI_PATTERNS:
        redacted = pattern.sub(placeholder, redacted)
    return redacted


def with_disclaimer(answer: str) -> str:
    """Append the standing clinical-use disclaimer to a model answer."""
    return answer.rstrip() + CLINICAL_DISCLAIMER


def has_sufficient_grounding(retrieved_docs: list, min_docs: int = 1) -> bool:
    """
    Simple grounding check: refuse to answer confidently if the retriever
    returned nothing. (Score-threshold filtering happens at the retriever
    level in rag_chain.py; this is a final backstop.)
    """
    return len(retrieved_docs) >= min_docs


NO_GROUNDING_RESPONSE = (
    "I couldn't find anything in the indexed guidelines relevant to that "
    "question. Please rephrase, narrow the question, or add the relevant "
    "source document to data/sample_docs/ and rebuild the index."
)
