# AWS Generative AI on Amazon Bedrock — Ride-Hailing Assistant (No RAG)

An end-to-end tour of AWS Bedrock generative AI capabilities, applied to a ride-hailing
domain. **No RAG, no vector database, no document retrieval** — every section is a
self-contained generative AI concept.

> **Note on naming:** this notebook models a *generic* ride-hailing platform for learning
> purposes (mock APIs, made-up data). It isn't affiliated with, built from, or using any
> real company's systems, data, or branding — swap in your own product's terminology and
> real API calls when adapting this for production use.

## Contents

```
uber_genai_bedrock/
├── Rideshare_GenAI_Bedrock.ipynb   # the main notebook — start here
├── requirements.txt
├── generated_images/               # output folder for generated promo images
└── README.md
```

## Concepts covered

1. **Basic text generation & personas** — a rider-support assistant system prompt
2. **Prompt engineering** — zero-shot vs. few-shot trip-cancellation classification
3. **Structured output** — extracting a ride request into a Pydantic/JSON schema
4. **Function calling / tool use** — mock ride status, driver ETA, and fare estimate APIs,
   shown as a manual bind-tools → execute → respond loop
5. **Conversational agent with memory** — the same tools wrapped in `langchain.agents.create_agent`
   with a LangGraph checkpointer for multi-turn memory
6. **Streaming** — token-by-token surge-pricing explanation
7. **Summarization** — condensing a trip safety-incident report
8. **Classification & sentiment** — triaging rider support tickets into structured JSON
9. **Grounded content generation** — turning a trip receipt (already known to your app, not
   retrieved) into a natural-language email
10. **Image generation** — Amazon Titan Image Generator creates city-launch promo artwork
11. **Guardrails** — masking rider/driver PII (phone numbers, addresses) and blocking unsafe
    or off-topic content

## Setup

1. **AWS account & Bedrock access**: In the AWS Console, go to **Bedrock → Model access**
   and request access to:
   - `anthropic.claude-3-5-sonnet-20240620-v1:0` (or another Claude model you prefer)
   - `amazon.titan-image-generator-v2:0`

2. **AWS credentials**: set these in your shell before launching Jupyter:
   ```bash
   export AWS_ACCESS_KEY_ID=your_key_id
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   ```
   Your IAM user/role needs `bedrock:InvokeModel` (and `bedrock:ListFoundationModels`,
   `bedrock:CreateGuardrail` if you want to run those optional cells).

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the notebook**:
   ```bash
   jupyter notebook Rideshare_GenAI_Bedrock.ipynb
   ```
   Run the cells top to bottom. The guardrails section is opt-in — it needs a guardrail
   you've created (either via the commented-out `create_guardrail` cell or the AWS console)
   and its ID set as the `BEDROCK_GUARDRAIL_ID` environment variable.

## Why PII masking matters here

Ride-hailing conversations routinely contain phone numbers, home/work addresses, and payment
details. Section 13 shows how Bedrock Guardrails can automatically anonymize or block that
kind of sensitive information in both prompts and model responses — important if you're
logging conversations or feeding them into analytics.

## Notes on versions

This notebook targets **LangChain v1.x**, which replaced the old `RetrievalQA` /
`ConversationalRetrievalChain` classes with LCEL pipelines and the LangGraph-based
`create_agent` API used here for the conversational agent section.
