"""
Ingestion pipeline: load source documents -> chunk -> embed via Amazon Titan
(Bedrock) -> persist a FAISS vector index.

Swap-in note: to move to production, replace `FAISS.from_documents` /
`FAISS.save_local` with `OpenSearchVectorSearch.from_documents(...)` pointed at
an Amazon OpenSearch Serverless collection. The rest of the pipeline
(loading, chunking, embeddings) is unchanged.
"""
import logging
from pathlib import Path

from langchain_aws import BedrockEmbeddings
from langchain_community.document_loaders import PyPDFLoader, TextLoader
from langchain_community.vectorstores import FAISS
from langchain_text_splitters import RecursiveCharacterTextSplitter

from src.config import settings
from src.guardrails import redact_phi

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)


def load_documents(data_dir: str):
    """Load every .txt and .pdf file in data_dir, tagging each with source metadata."""
    docs = []
    data_path = Path(data_dir)
    if not data_path.exists():
        raise FileNotFoundError(f"Data directory not found: {data_path.resolve()}")

    for file_path in sorted(data_path.glob("*")):
        if file_path.suffix.lower() == ".txt":
            loader = TextLoader(str(file_path), encoding="utf-8")
        elif file_path.suffix.lower() == ".pdf":
            loader = PyPDFLoader(str(file_path))
        else:
            continue

        loaded = loader.load()
        for doc in loaded:
            doc.page_content = redact_phi(doc.page_content)
            doc.metadata["source"] = file_path.name
        docs.extend(loaded)
        logger.info("Loaded %s (%d page/section chunk(s))", file_path.name, len(loaded))

    if not docs:
        raise ValueError(f"No .txt or .pdf documents found in {data_path.resolve()}")
    return docs


def chunk_documents(docs, chunk_size: int, chunk_overlap: int):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )
    chunks = splitter.split_documents(docs)
    logger.info("Split %d document(s) into %d chunk(s)", len(docs), len(chunks))
    return chunks


def build_embeddings() -> BedrockEmbeddings:
    return BedrockEmbeddings(
        model_id=settings.bedrock_embedding_model_id,
        region_name=settings.aws_region,
    )


def build_index(chunks, embeddings: BedrockEmbeddings) -> FAISS:
    logger.info("Embedding %d chunks via %s ...", len(chunks), settings.bedrock_embedding_model_id)
    vectorstore = FAISS.from_documents(chunks, embeddings)
    return vectorstore


def run_ingestion() -> None:
    docs = load_documents(settings.data_dir)
    chunks = chunk_documents(docs, settings.chunk_size, settings.chunk_overlap)
    embeddings = build_embeddings()
    vectorstore = build_index(chunks, embeddings)

    out_path = Path(settings.vector_store_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    vectorstore.save_local(str(out_path))
    logger.info("Saved FAISS index to %s", out_path.resolve())


if __name__ == "__main__":
    run_ingestion()
