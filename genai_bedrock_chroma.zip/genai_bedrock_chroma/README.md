# Generative AI Application with AWS Bedrock + Chroma

A Retrieval-Augmented Generation (RAG) generative AI application built with LangChain,
AWS Bedrock, and the Chroma vector database — in a single runnable Jupyter notebook.

## Contents

```
genai_bedrock_chroma/
├── GenAI_App_Bedrock_Chroma.ipynb   # the main notebook — start here
├── requirements.txt
├── sample_docs/                     # tiny sample knowledge base
│   ├── company_handbook.txt
│   ├── product_faq.txt
│   └── support_policy.txt
├── chroma_db/                       # created on first run — persisted Chroma collection
└── README.md
```

## What it does

1. Loads documents from `sample_docs/`
2. Splits them into overlapping chunks
3. Embeds the chunks with Amazon Titan Text Embeddings (via Bedrock)
4. Stores the embeddings in a **Chroma** vector database, persisted to `chroma_db/`
5. Retrieves relevant chunks for a query
6. **Grounded Q&A** — answers questions with Claude on Bedrock, using only retrieved context
7. **Grounded content generation** — drafts content (e.g. a customer email) using retrieved facts
8. **Conversational agent with memory** — a tool-calling agent (`langchain.agents.create_agent`)
   that decides when to search the knowledge base and remembers prior turns in a conversation

## Setup

1. **AWS account & Bedrock access**: In the AWS Console, go to **Bedrock → Model access**
   and request access to:
   - `amazon.titan-embed-text-v2:0`
   - `anthropic.claude-3-5-sonnet-20240620-v1:0` (or another Claude model you prefer)

2. **AWS credentials**: set these in your shell before launching Jupyter (don't hardcode them
   in the notebook):
   ```bash
   export AWS_ACCESS_KEY_ID=your_key_id
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   ```
   Your IAM user/role needs `bedrock:InvokeModel` permission (and `bedrock:ListFoundationModels`
   if you want to run the optional model-listing sanity check).

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the notebook**:
   ```bash
   jupyter notebook GenAI_App_Bedrock_Chroma.ipynb
   ```
   Run the cells top to bottom.

## Why Chroma?

Chroma is an open-source embedding database that runs embedded (in-process, no server needed)
for local development, and can also run in client/server mode for production. This notebook
uses the embedded mode with `persist_directory="chroma_db"`, so your collection survives
across notebook restarts without re-embedding your documents.

## Using your own data

Replace the files in `sample_docs/` with your own `.txt` files, or swap the loader in the
notebook (`DirectoryLoader` + `TextLoader`) for one of LangChain's other document loaders
(`PyPDFLoader`, `UnstructuredWordDocumentLoader`, `WebBaseLoader`, `S3DirectoryLoader`, etc.)
to ingest PDFs, Word docs, web pages, or S3 buckets. Everything downstream (splitting,
embedding, retrieval, generation) stays the same.

## Notes on versions

This notebook targets **LangChain v1.x**, which replaced the old `RetrievalQA` and
`ConversationalRetrievalChain` classes with LCEL pipelines and the LangGraph-based
`create_agent` API. If you're pinned to an older LangChain 0.x release, the legacy chain
classes still exist there but are deprecated upstream.
