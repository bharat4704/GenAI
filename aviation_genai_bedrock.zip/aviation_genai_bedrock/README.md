# AWS Generative AI on Amazon Bedrock — Aviation Assistant (No RAG)

An end-to-end tour of AWS Bedrock generative AI capabilities, applied to an airline /
aviation use case. **No RAG, no vector database, no document retrieval** — every section
is a self-contained generative AI concept.

## Contents

```
aviation_genai_bedrock/
├── Aviation_GenAI_Bedrock.ipynb   # the main notebook — start here
├── requirements.txt
├── generated_images/              # output folder for generated poster images
└── README.md
```

## Concepts covered

1. **Basic text generation & personas** — an aviation assistant system prompt
2. **Prompt engineering** — zero-shot vs. few-shot delay-cause classification
3. **Structured output** — extracting a flight booking request into a Pydantic/JSON schema
4. **Function calling / tool use** — mock flight status, weather, and seat-availability APIs,
   shown as a manual bind-tools → execute → respond loop
5. **Conversational agent with memory** — the same tools wrapped in `langchain.agents.create_agent`
   with a LangGraph checkpointer for multi-turn memory
6. **Streaming** — token-by-token delay explanation
7. **Summarization** — condensing a maintenance/incident log
8. **Classification & sentiment** — triaging customer support tickets into structured JSON
9. **Grounded content generation** — turning structured flight data (already known to your app,
   not retrieved) into a natural-language safety briefing script
10. **Image generation** — Amazon Titan Image Generator creates a route promotional poster
11. **Guardrails** — creating and attaching an Amazon Bedrock Guardrail to filter unsafe/off-topic content

## Setup

1. **AWS account & Bedrock access**: In the AWS Console, go to **Bedrock → Model access**
   and request access to:
   - `anthropic.claude-3-5-sonnet-20240620-v1:0` (or another Claude model you prefer)
   - `amazon.titan-image-generator-v2:0`

2. **AWS credentials**: set these in your shell before launching Jupyter:
   ```bash
   export AWS_ACCESS_KEY_ID=your_key_id
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   ```
   Your IAM user/role needs `bedrock:InvokeModel` (and `bedrock:ListFoundationModels`,
   `bedrock:CreateGuardrail` if you want to run those optional cells).

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the notebook**:
   ```bash
   jupyter notebook Aviation_GenAI_Bedrock.ipynb
   ```
   Run the cells top to bottom. The guardrails section is opt-in — it needs a guardrail
   you've created (either via the commented-out `create_guardrail` cell or the AWS console)
   and its ID set as the `BEDROCK_GUARDRAIL_ID` environment variable.

## Notes on versions

This notebook targets **LangChain v1.x**, which replaced the old `RetrievalQA` /
`ConversationalRetrievalChain` classes with LCEL pipelines and the LangGraph-based
`create_agent` API used here for the conversational agent section.
