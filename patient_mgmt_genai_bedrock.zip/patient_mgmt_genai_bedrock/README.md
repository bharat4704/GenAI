# AWS Generative AI on Amazon Bedrock — Patient Management Assistant (No RAG)

An end-to-end tour of AWS Bedrock generative AI capabilities, applied to **administrative and
operational** patient management for a clinic front office. **No RAG, no vector database, no
document retrieval** — every section is a self-contained generative AI concept.

## ⚠️ Scope and safety

This assistant handles **administrative tasks only**: scheduling, intake forms, billing
questions, message routing, and plain-language recaps of information a clinician already
documented. It is explicitly **not** a diagnostic tool.

- Every system prompt instructs the model to decline clinical questions and defer to the
  care team (or emergency services for anything urgent).
- The classification/triage sections route messages by *department and queue priority*,
  never by medical severity or diagnosis.
- Summarization and content-generation prompts are instructed to restate only what's
  explicitly documented — never to infer or add clinical interpretation.
- Section 13 shows Bedrock Guardrails enforcing this scope as a second line of defense, on
  top of the system prompt.
- All sample data (patient names, visit notes, appointment records) is entirely fictitious.

**HIPAA:** Amazon Bedrock is a HIPAA-eligible service, but using it with real Protected Health
Information requires an executed Business Associate Addendum (BAA) with AWS and following
AWS's HIPAA reference architecture. Treat any adaptation of this notebook to real patient
data as a compliance project, not just an engineering one.

## Contents

```
patient_mgmt_genai_bedrock/
├── Patient_Management_GenAI_Bedrock.ipynb   # the main notebook — start here
├── requirements.txt
├── generated_images/                        # output folder for generated poster images
└── README.md
```

## Concepts covered

1. **Basic text generation & personas** — "Carely" front-desk care-coordinator assistant, with
   a hard-coded refusal for clinical questions
2. **Prompt engineering** — zero-shot vs. few-shot message routing (by department, not diagnosis)
3. **Structured output** — parsing a new-patient intake message into a Pydantic/JSON schema
4. **Function calling / tool use** — mock appointment-slot lookup, appointment status, and
   reminder APIs, shown as a manual bind-tools → execute → respond loop
5. **Conversational agent with memory** — the same tools wrapped in `langchain.agents.create_agent`
   with a LangGraph checkpointer for multi-turn memory
6. **Streaming** — token-by-token plain-language billing explanation
7. **Summarization** — turning a clinician's visit note into a patient-friendly after-visit
   summary, restating only what's documented
8. **Classification & urgency triage** — routing patient messages into department + queue
   priority as structured JSON (explicitly not a clinical triage)
9. **Grounded content generation** — turning discharge instructions (already documented, not
   retrieved) into a warm recap message
10. **Image generation** — Amazon Titan Image Generator creates a generic wellness poster
    (no depictions of procedures or people)
11. **Guardrails** — masking PHI (names, phone numbers, SSNs) and blocking diagnostic/treatment
    content as a second line of defense

## Setup

1. **AWS account & Bedrock access**: In the AWS Console, go to **Bedrock → Model access**
   and request access to:
   - `anthropic.claude-3-5-sonnet-20240620-v1:0` (or another Claude model you prefer)
   - `amazon.titan-image-generator-v2:0`

2. **AWS credentials**: set these in your shell before launching Jupyter:
   ```bash
   export AWS_ACCESS_KEY_ID=your_key_id
   export AWS_SECRET_ACCESS_KEY=your_secret_key
   export AWS_DEFAULT_REGION=us-east-1
   ```
   Your IAM user/role needs `bedrock:InvokeModel` (and `bedrock:ListFoundationModels`,
   `bedrock:CreateGuardrail` if you want to run those optional cells).

3. **Install dependencies**:
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the notebook**:
   ```bash
   jupyter notebook Patient_Management_GenAI_Bedrock.ipynb
   ```
   Run the cells top to bottom. The guardrails section is opt-in — it needs a guardrail
   you've created (either via the commented-out `create_guardrail` cell or the AWS console)
   and its ID set as the `BEDROCK_GUARDRAIL_ID` environment variable.

## Notes on versions

This notebook targets **LangChain v1.x**, which replaced the old `RetrievalQA` /
`ConversationalRetrievalChain` classes with LCEL pipelines and the LangGraph-based
`create_agent` API used here for the conversational agent section.
