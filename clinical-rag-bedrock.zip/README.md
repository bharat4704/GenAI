# Clinical Document Q&A — RAG with Amazon Bedrock + LangChain

An end-to-end Retrieval-Augmented Generation (RAG) project that lets clinicians and
care teams ask natural-language questions over a corpus of clinical guidelines,
care pathways, and (synthetic) patient documentation — grounded strictly in the
retrieved source text, with citations and a built-in safety disclaimer.

Built the way you'd stand this up for a Fortune 500 payer/provider: Bedrock-native
embeddings + LLM, a swappable vector store, PHI-aware guardrails, and a clean path
from local prototype (FAISS) to production (Amazon OpenSearch Serverless).

> ⚠️ **Synthetic data only.** `data/sample_docs/` contains fabricated, non-PHI
> clinical guidelines written for this project. Do not drop real patient records
> into this repo without a signed BAA, a HIPAA-eligible AWS account setup, and
> your org's security review.

---

## 1. Architecture

```
                     ┌─────────────────────────┐
                     │   Source Documents       │
                     │  (guidelines, protocols, │
                     │   discharge notes, PDFs) │
                     └────────────┬─────────────┘
                                  │
                          chunk (RecursiveCharacterTextSplitter)
                                  │
                                  ▼
                     ┌─────────────────────────┐
                     │  Amazon Titan Embeddings │
                     │  (via Bedrock)           │
                     └────────────┬─────────────┘
                                  │
                                  ▼
                     ┌─────────────────────────┐
                     │  Vector Store            │
                     │  FAISS (local/dev)  -or-  │
                     │  OpenSearch Serverless    │
                     │  (production)             │
                     └────────────┬─────────────┘
                                  │  similarity search (top-k)
                                  ▼
                     ┌─────────────────────────┐
                     │  PHI / Safety Guardrails  │
                     │  (redaction + filtering) │
                     └────────────┬─────────────┘
                                  │
                                  ▼
                     ┌─────────────────────────┐
                     │  Claude on Bedrock        │
                     │  (via LangChain           │
                     │   RetrievalQA / LCEL)     │
                     └────────────┬─────────────┘
                                  │
                                  ▼
                     ┌─────────────────────────┐
                     │  Answer + Source          │
                     │  Citations + Disclaimer   │
                     └─────────────────────────┘
```

See [`architecture.md`](architecture.md) for the production topology (S3, IAM,
Lambda/API Gateway, CloudWatch, Bedrock Guardrails) and cost/scaling notes.

---

## 2. Project layout

```
clinical-rag-bedrock/
├── README.md
├── architecture.md
├── requirements.txt
├── .env.example
├── data/
│   └── sample_docs/          # synthetic clinical guidelines (.txt)
├── src/
│   ├── config.py             # env-driven configuration
│   ├── guardrails.py         # PHI redaction + safety disclaimer
│   ├── ingest.py             # load -> chunk -> embed -> index
│   ├── build_index.py        # CLI entrypoint for ingestion
│   ├── rag_chain.py          # LangChain retrieval + Bedrock LLM chain
│   └── app.py                # interactive CLI Q&A
├── tests/
│   └── test_guardrails.py
└── vectorstore/               # FAISS index gets written here
```

---

## 3. Prerequisites

- Python 3.10+
- An AWS account with **Bedrock model access enabled** for:
  - `anthropic.claude-3-5-sonnet-20241022-v2:0` (or your preferred Claude model)
  - `amazon.titan-embed-text-v2:0`
- IAM credentials (user/role) with `bedrock:InvokeModel` permission, configured via
  `aws configure` or environment variables.

## 4. Setup

```bash
cd clinical-rag-bedrock
python -m venv .venv && source .venv/bin/activate      # or .venv\Scripts\activate on Windows
pip install -r requirements.txt
cp .env.example .env                                     # then edit as needed
```

## 5. Build the vector index

```bash
python -m src.build_index
```

This reads every `.txt`/`.pdf` in `data/sample_docs/`, chunks it, embeds each chunk
with Titan Embeddings, and persists a FAISS index to `vectorstore/faiss_index/`.

## 6. Ask questions

```bash
python -m src.app
```

```
Clinical Doc Q&A — type 'exit' to quit
> What's the first-line pharmacologic treatment for a newly diagnosed type 2 diabetic with no comorbidities?
```

Every answer includes:
- A grounded response synthesized **only** from retrieved chunks
- The source document(s) and section used
- A standing clinical disclaimer ("informational support tool, not a substitute
  for clinical judgment")

If the retriever finds nothing relevant above the similarity threshold, the chain
is instructed to say so rather than guess.

---

## 6. Guardrails & compliance notes

- `src/guardrails.py` regex-redacts common PHI patterns (SSN, MRN, DOB-like
  strings) before any text is logged or sent in prompts you build on top of this
  (e.g., if you extend ingestion to real patient notes).
- For production, pair this with **Amazon Bedrock Guardrails** (content filters,
  denied topics, PII masking) attached directly to the model invocation — this
  project's guardrail module is a lightweight stand-in you can extend or replace.
- Recommended production controls: VPC endpoints for Bedrock, KMS-encrypted S3 +
  OpenSearch, CloudTrail logging on all `InvokeModel` calls, and a signed AWS BAA
  before any real PHI touches the pipeline.

---

## 7. Try it yourself — extensions

1. **Swap FAISS for OpenSearch Serverless** — use `langchain-community`'s
   `OpenSearchVectorSearch` so the index lives in a managed, scalable store.
2. **Add hybrid search** — combine BM25 keyword search with vector similarity
   (`rank_bm25`) for better recall on drug names and dosages.
3. **Ingest real PDFs** — drop discharge summaries or CDC/WHO guideline PDFs into
   `data/sample_docs/` (already wired via `pypdf`) and re-run `build_index`.
4. **Attach Bedrock Guardrails** — create a guardrail in the Bedrock console and
   pass `guardrailIdentifier`/`guardrailVersion` in the `ChatBedrock` call.
5. **Wrap it in an API** — expose `src/rag_chain.py` behind a FastAPI endpoint,
   containerize it, and deploy on ECS Fargate or Lambda (see `architecture.md`).
6. **Add conversation memory** — use `RunnableWithMessageHistory` so clinicians
   can ask follow-up questions ("what about for a patient with renal impairment?").
7. **Evaluate answer quality** — build a small eval set of Q/A pairs and score
   groundedness with `langchain`'s `QAEvalChain` or Ragas.

---

## 8. Disclaimer

This is a training/demo project. It is **not** a certified clinical decision
support system and must not be used for real patient care without appropriate
validation, regulatory review, and clinical oversight.
