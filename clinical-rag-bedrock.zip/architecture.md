# Production Architecture Notes

The code in this repo is a local/dev-mode prototype (FAISS, CLI). This document
sketches how to take it to a production posture on AWS.

## Target production topology

```
Clinicians / Care Team
        │
        ▼
  API Gateway (HTTPS) ──► Lambda (or ECS Fargate service)
        │                        │
        │                        ├─► Bedrock: InvokeModel (Titan Embeddings)
        │                        ├─► Bedrock: InvokeModel (Claude, w/ Guardrail)
        │                        └─► Amazon OpenSearch Serverless (vector store)
        │
        ▼
  CloudWatch Logs/Metrics + CloudTrail (audit)

Document ingestion (offline/batch):
  S3 (raw guideline PDFs/docs, versioned, KMS-encrypted)
        │
        ▼
  Step Functions / Lambda ingestion job
        │  (chunk → Titan embeddings → upsert)
        ▼
  Amazon OpenSearch Serverless (vector index)
```

## Key production swaps from this prototype

| Prototype (this repo)        | Production                                          |
|------------------------------|------------------------------------------------------|
| Local `.txt`/`.pdf` in repo  | S3 bucket, versioned, KMS-encrypted, BAA-covered      |
| FAISS local index            | Amazon OpenSearch Serverless (vector engine)          |
| CLI (`src/app.py`)           | API Gateway + Lambda/Fargate behind auth (Cognito/IAM)|
| `src/guardrails.py` regex    | Amazon Bedrock Guardrails (PII masking, denied topics)|
| Manual `build_index` run     | Step Functions pipeline triggered on S3 upload        |
| No auth                      | IAM roles scoped to least privilege per component      |

## IAM considerations
- Ingestion Lambda role: `bedrock:InvokeModel` (embeddings only), `s3:GetObject`
  on the source bucket, `aoss:APIAccessAll` scoped to the specific collection.
- Query-time Lambda/Fargate role: `bedrock:InvokeModel` (Claude + embeddings),
  read-only `aoss` access — no write permissions needed at query time.
- Use resource-based policies/VPC endpoints for Bedrock and OpenSearch so
  traffic never traverses the public internet.

## Observability
- Enable CloudTrail data events for `bedrock:InvokeModel` to get an audit
  trail of every prompt/response pair (useful for compliance review).
- Emit custom CloudWatch metrics for: retrieval latency, LLM latency, "no
  grounding found" rate (a proxy for knowledge-base coverage gaps), and
  guardrail intervention rate.
- Consider Bedrock's native invocation logging (S3/CloudWatch) to capture
  full request/response payloads for audit, with PHI redaction applied before
  storage.

## Cost/scaling notes
- Titan Embeddings and Claude are billed per token; batch re-embedding runs
  during off-peak hours and cache embeddings per chunk (don't re-embed
  unchanged documents).
- OpenSearch Serverless bills by OCU (OpenSearch Compute Unit); a small
  knowledge base (a few thousand chunks) typically fits comfortably within
  the minimum OCU allocation for indexing + search.
- For bursty query traffic, prefer Lambda (pay-per-invocation); for steady,
  latency-sensitive traffic, prefer a small always-on Fargate service to
  avoid cold starts on the LangChain/FAISS-equivalent client initialization.

## Compliance checklist before any real PHI is used
- [ ] Signed AWS Business Associate Addendum (BAA) in place
- [ ] Data classified and stored only in HIPAA-eligible services (S3, Lambda,
      Bedrock, OpenSearch Serverless are all HIPAA-eligible when configured
      per AWS's guidance)
- [ ] KMS encryption at rest on all data stores; TLS in transit everywhere
- [ ] Bedrock Guardrails configured for PII/PHI masking and denied topics
- [ ] Access logging + CloudTrail enabled and retained per policy
- [ ] Clinical and security sign-off on the guideline corpus and prompt design
