"""
Centralized, env-driven configuration for the Clinical Doc Q&A project.

All values can be overridden via a .env file (see .env.example) or real
environment variables. Nothing here should contain secrets — AWS credentials
are resolved by boto3's standard credential chain (env vars, ~/.aws/credentials,
instance/role profile, etc.), never hardcoded.
"""
import os
from dataclasses import dataclass

from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Settings:
    # AWS / Bedrock
    aws_region: str = os.getenv("AWS_REGION", "us-east-1")
    aws_profile: str = os.getenv("AWS_PROFILE", "default")

    bedrock_llm_model_id: str = os.getenv(
        "BEDROCK_LLM_MODEL_ID", "anthropic.claude-3-5-sonnet-20241022-v2:0"
    )
    bedrock_embedding_model_id: str = os.getenv(
        "BEDROCK_EMBEDDING_MODEL_ID", "amazon.titan-embed-text-v2:0"
    )

    # Optional Bedrock Guardrails (leave blank to skip)
    guardrail_id: str = os.getenv("BEDROCK_GUARDRAIL_ID", "")
    guardrail_version: str = os.getenv("BEDROCK_GUARDRAIL_VERSION", "")

    # Ingestion
    data_dir: str = os.getenv("DATA_DIR", "data/sample_docs")
    vector_store_path: str = os.getenv("VECTOR_STORE_PATH", "vectorstore/faiss_index")
    chunk_size: int = int(os.getenv("CHUNK_SIZE", "1000"))
    chunk_overlap: int = int(os.getenv("CHUNK_OVERLAP", "150"))

    # Retrieval
    top_k: int = int(os.getenv("TOP_K", "4"))
    score_threshold: float = float(os.getenv("SCORE_THRESHOLD", "0.35"))


settings = Settings()
